import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// En desarrollo (npm run dev) las llamadas a /habitos se redirigen al backend en el puerto 3000
export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: { proxy: { '/habitos': 'http://localhost:3000' } },
})
