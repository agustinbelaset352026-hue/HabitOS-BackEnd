import { useCallback, useEffect, useState } from 'react'
import { api } from './api'

// Reemplaza al hook que guardaba en localStorage: ahora los datos viven en el backend.
export function useHabitos() {
  const [habitos, setHabitos] = useState([])
  const [stats, setStats] = useState({})
  const [filtros, setFiltros] = useState({ buscar: '', categoria: '', estado: '', favorito: '' })
  const [cargando, setCargando] = useState(true)
  const [error, setError] = useState('')

  const cargar = useCallback(async () => {
    try {
      const lista = await api.listar(filtros)
      const pares = await Promise.all(lista.map(async (h) => [h.id, await api.estadisticas(h.id)]))
      setHabitos(lista)
      setStats(Object.fromEntries(pares))
      setError('')
    } catch (e) {
      setError(e.message)
    } finally {
      setCargando(false)
    }
  }, [filtros])

  // La búsqueda espera 250 ms después de dejar de escribir
  useEffect(() => {
    const t = setTimeout(cargar, 250)
    return () => clearTimeout(t)
  }, [cargar])

  // Ejecuta una acción; devuelve true si salió bien
  const ejecutar = async (accion) => {
    try {
      await accion()
      await cargar()
      return true
    } catch (e) {
      setError(e.message)
      return false
    }
  }

  return {
    habitos, stats, filtros, setFiltros, cargando, error, limpiarError: () => setError(''),
    crear: (d) => ejecutar(() => api.crear(d)),
    editar: (id, d) => ejecutar(() => api.editar(id, d)),
    eliminar: (id) => ejecutar(() => api.eliminar(id)),
    completar: (id) => ejecutar(() => api.completar(id)),
    alternarFavorito: (id) => ejecutar(() => api.favorito(id)),
    cambiarEstado: (id, e) => ejecutar(() => api.estado(id, e)),
  }
}
