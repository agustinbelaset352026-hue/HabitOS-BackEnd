import { useState } from 'react'

export const CATEGORIAS_BASE = ['Salud', 'Mente', 'Estudio', 'Trabajo', 'Social', 'Otro']

// Validación simple para avisar rápido; la validación de verdad está en el backend.
export default function FormularioHabito({ inicial, onGuardar, onCancelar }) {
  const [datos, setDatos] = useState({
    titulo: inicial?.titulo ?? '',
    descripcion: inicial?.descripcion ?? '',
    categoria: inicial?.categoria ?? 'Otro',
    frecuencia: inicial?.frecuencia ?? 'diaria',
    favorito: inicial?.favorito ?? false,
  })
  const [errorLocal, setErrorLocal] = useState('')
  const [guardando, setGuardando] = useState(false)
  const cambiar = (campo) => (e) =>
    setDatos({ ...datos, [campo]: e.target.type === 'checkbox' ? e.target.checked : e.target.value })

  const enviar = async (e) => {
    e.preventDefault()
    if (!datos.titulo.trim()) return setErrorLocal('El hábito necesita un título.')
    setErrorLocal('')
    setGuardando(true)
    const ok = await onGuardar(datos)
    setGuardando(false)
    if (ok && !inicial) setDatos({ ...datos, titulo: '', descripcion: '', favorito: false })
  }

  const campo = 'w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500'
  const categorias = [...new Set([...CATEGORIAS_BASE, datos.categoria])]

  return (
    <form onSubmit={enviar} className="space-y-3 rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <h2 className="font-semibold">{inicial ? 'Editar hábito' : 'Nuevo hábito'}</h2>
      <div>
        <input className={campo} placeholder="Título (ej: Tomar agua)" value={datos.titulo} onChange={cambiar('titulo')} maxLength={100} />
        {errorLocal && <p className="mt-1 text-sm text-red-600">{errorLocal}</p>}
      </div>
      <textarea className={campo} rows={2} placeholder="Descripción (opcional)" value={datos.descripcion} onChange={cambiar('descripcion')} maxLength={500} />
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <select className={campo} value={datos.categoria} onChange={cambiar('categoria')}>
          {categorias.map((c) => <option key={c}>{c}</option>)}
        </select>
        <select className={campo} value={datos.frecuencia} onChange={cambiar('frecuencia')}>
          <option value="diaria">Diaria</option>
          <option value="semanal">Semanal</option>
        </select>
      </div>
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={datos.favorito} onChange={cambiar('favorito')} /> Marcar como favorito
      </label>
      <div className="flex gap-2">
        <button disabled={guardando} className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:opacity-50">
          {inicial ? 'Guardar cambios' : 'Agregar hábito'}
        </button>
        {onCancelar && (
          <button type="button" onClick={onCancelar} className="rounded-lg border border-slate-300 px-4 py-2 text-sm hover:bg-slate-100">
            Cancelar
          </button>
        )}
      </div>
    </form>
  )
}
