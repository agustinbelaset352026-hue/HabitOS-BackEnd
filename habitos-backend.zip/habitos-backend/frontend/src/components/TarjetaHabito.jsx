const colorEstado = {
  activo: 'bg-emerald-100 text-emerald-700',
  pausado: 'bg-amber-100 text-amber-700',
  archivado: 'bg-slate-200 text-slate-600',
}

function Dato({ valor, etiqueta }) {
  return (
    <div className="rounded-lg bg-slate-50 px-2 py-2 text-center">
      <div className="text-lg font-semibold">{valor}</div>
      <div className="text-xs text-slate-500">{etiqueta}</div>
    </div>
  )
}

export default function TarjetaHabito({ habito, stats, onCompletar, onFavorito, onEstado, onEditar, onEliminar }) {
  const hecho = stats?.completadoHoy
  const unidad = stats?.unidadRacha ?? 'días'
  return (
    <article className={`rounded-xl border bg-white p-4 shadow-sm ${habito.estado !== 'activo' ? 'opacity-75' : ''} ${hecho ? 'border-emerald-300' : 'border-slate-200'}`}>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <h3 className="break-words font-semibold">{habito.titulo}</h3>
          {habito.descripcion && <p className="mt-0.5 break-words text-sm text-slate-500">{habito.descripcion}</p>}
        </div>
        <button onClick={onFavorito} aria-label="Favorito" title="Favorito" className={`text-2xl leading-none ${habito.favorito ? 'text-amber-400' : 'text-slate-300 hover:text-amber-300'}`}>
          ★
        </button>
      </div>

      <div className="mt-2 flex flex-wrap gap-1.5 text-xs">
        <span className="rounded-full bg-indigo-100 px-2 py-0.5 text-indigo-700">{habito.categoria}</span>
        <span className="rounded-full bg-slate-100 px-2 py-0.5 text-slate-600">{habito.frecuencia}</span>
        <span className={`rounded-full px-2 py-0.5 ${colorEstado[habito.estado]}`}>{habito.estado}</span>
      </div>

      {stats && (
        <div className="mt-3 grid grid-cols-4 gap-2">
          <Dato valor={`🔥 ${stats.rachaActual}`} etiqueta={`racha (${unidad})`} />
          <Dato valor={stats.rachaMasLarga} etiqueta="mejor racha" />
          <Dato valor={`${stats.porcentaje7Dias}%`} etiqueta="7 días" />
          <Dato valor={`${stats.porcentaje30Dias}%`} etiqueta="30 días" />
        </div>
      )}

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <button onClick={onCompletar} disabled={hecho} className="rounded-lg bg-emerald-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-emerald-700 disabled:bg-slate-200 disabled:text-slate-500">
          {hecho ? '✓ Hecho hoy' : 'Completar hoy'}
        </button>
        <select value={habito.estado} onChange={(e) => onEstado(e.target.value)} className="rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-sm">
          <option value="activo">Activo</option>
          <option value="pausado">Pausado</option>
          <option value="archivado">Archivado</option>
        </select>
        <button onClick={onEditar} className="rounded-lg border border-slate-300 px-3 py-1.5 text-sm hover:bg-slate-100">Editar</button>
        <button onClick={onEliminar} className="rounded-lg border border-red-200 px-3 py-1.5 text-sm text-red-600 hover:bg-red-50">Eliminar</button>
      </div>
    </article>
  )
}
