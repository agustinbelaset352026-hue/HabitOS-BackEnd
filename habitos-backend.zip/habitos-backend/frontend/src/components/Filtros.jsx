import { CATEGORIAS_BASE } from './FormularioHabito'

export default function Filtros({ filtros, setFiltros, categoriasExtra }) {
  const cambiar = (campo) => (e) => setFiltros({ ...filtros, [campo]: e.target.value })
  const campo = 'rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500'
  const categorias = [...new Set([...CATEGORIAS_BASE, ...categoriasExtra])]
  return (
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
      <input className={`${campo} col-span-2 sm:col-span-4`} placeholder="Buscar por nombre…" value={filtros.buscar} onChange={cambiar('buscar')} />
      <select className={campo} value={filtros.categoria} onChange={cambiar('categoria')}>
        <option value="">Todas las categorías</option>
        {categorias.map((c) => <option key={c}>{c}</option>)}
      </select>
      <select className={campo} value={filtros.estado} onChange={cambiar('estado')}>
        <option value="">Todos los estados</option>
        <option value="activo">Activos</option>
        <option value="pausado">Pausados</option>
        <option value="archivado">Archivados</option>
      </select>
      <select className={campo} value={filtros.favorito} onChange={cambiar('favorito')}>
        <option value="">Favoritos y no</option>
        <option value="true">Solo favoritos</option>
        <option value="false">No favoritos</option>
      </select>
      <button onClick={() => setFiltros({ buscar: '', categoria: '', estado: '', favorito: '' })} className="rounded-lg border border-slate-300 px-3 py-2 text-sm hover:bg-slate-100">
        Limpiar filtros
      </button>
    </div>
  )
}
