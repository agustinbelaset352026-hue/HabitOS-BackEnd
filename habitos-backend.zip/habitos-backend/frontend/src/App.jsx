import { useState } from 'react'
import { useHabitos } from './useHabitos'
import FormularioHabito from './components/FormularioHabito'
import Filtros from './components/Filtros'
import TarjetaHabito from './components/TarjetaHabito'

export default function App() {
  const h = useHabitos()
  const [editando, setEditando] = useState(null)

  const eliminar = (hab) => {
    if (window.confirm(`¿Eliminar "${hab.titulo}"? Se pierde su historial.`)) h.eliminar(hab.id)
  }
  const guardarEdicion = async (datos) => {
    const ok = await h.editar(editando.id, datos)
    if (ok) setEditando(null)
    return ok
  }
  const hechosHoy = h.habitos.filter((x) => h.stats[x.id]?.completadoHoy).length

  return (
    <div className="mx-auto max-w-3xl space-y-4 px-4 py-6">
      <header className="flex items-end justify-between">
        <div>
          <h1 className="text-2xl font-bold text-indigo-700">HábitOS</h1>
          <p className="text-sm text-slate-500">Seguí tus hábitos y mantené tu racha.</p>
        </div>
        {h.habitos.length > 0 && (
          <p className="text-sm text-slate-600">Hoy: <b>{hechosHoy}</b> de {h.habitos.length}</p>
        )}
      </header>

      {h.error && (
        <div role="alert" className="flex items-start justify-between gap-2 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
          <span>{h.error}</span>
          <button onClick={h.limpiarError} aria-label="Cerrar">✕</button>
        </div>
      )}

      {editando ? (
        <FormularioHabito key={editando.id} inicial={editando} onGuardar={guardarEdicion} onCancelar={() => setEditando(null)} />
      ) : (
        <FormularioHabito onGuardar={h.crear} />
      )}

      <Filtros filtros={h.filtros} setFiltros={h.setFiltros} categoriasExtra={h.habitos.map((x) => x.categoria)} />

      {h.cargando ? (
        <p className="py-8 text-center text-slate-500">Cargando…</p>
      ) : h.habitos.length === 0 ? (
        <p className="py-8 text-center text-slate-500">No hay hábitos para mostrar. ¡Agregá el primero!</p>
      ) : (
        <div className="space-y-3">
          {h.habitos.map((hab) => (
            <TarjetaHabito
              key={hab.id}
              habito={hab}
              stats={h.stats[hab.id]}
              onCompletar={() => h.completar(hab.id)}
              onFavorito={() => h.alternarFavorito(hab.id)}
              onEstado={(e) => h.cambiarEstado(hab.id, e)}
              onEditar={() => { setEditando(hab); window.scrollTo({ top: 0, behavior: 'smooth' }) }}
              onEliminar={() => eliminar(hab)}
            />
          ))}
        </div>
      )}
    </div>
  )
}
