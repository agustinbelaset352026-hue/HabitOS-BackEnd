// Todas las llamadas al backend. Mismo origen por defecto; se puede cambiar con VITE_API_URL.
const BASE = import.meta.env.VITE_API_URL || ''

async function pedir(metodo, ruta, body) {
  let res
  try {
    res = await fetch(BASE + ruta, {
      method: metodo,
      headers: { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    })
  } catch {
    throw new Error('No se pudo conectar con el servidor.')
  }
  const data = await res.json().catch(() => null)
  if (!res.ok) throw new Error(data?.error || 'Ocurrió un error inesperado.')
  return data
}

export const api = {
  listar: (filtros = {}) => {
    const q = new URLSearchParams(Object.entries(filtros).filter(([, v]) => v !== '' && v !== undefined))
    return pedir('GET', `/habitos${q.toString() ? `?${q}` : ''}`)
  },
  crear: (datos) => pedir('POST', '/habitos', datos),
  editar: (id, datos) => pedir('PUT', `/habitos/${id}`, datos),
  eliminar: (id) => pedir('DELETE', `/habitos/${id}`),
  completar: (id) => pedir('POST', `/habitos/${id}/completar`),
  favorito: (id) => pedir('PATCH', `/habitos/${id}/favorito`),
  estado: (id, estado) => pedir('PATCH', `/habitos/${id}/estado`, { estado }),
  estadisticas: (id) => pedir('GET', `/habitos/${id}/estadisticas`),
}
