// Errores con código HTTP, lanzados por el Service
class ErrorHabitos extends Error {
  constructor(status, mensaje) {
    super(mensaje)
    this.status = status
  }
}

// Convierte cualquier error en una respuesta JSON clara (nunca una página HTML)
function manejarErrores(err, req, res, next) {
  if (res.headersSent) return next(err)
  if (err instanceof ErrorHabitos) return res.status(err.status).json({ error: err.message })
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'El JSON enviado está mal formado.' })
  }
  if (err.type === 'entity.too.large') {
    return res.status(413).json({ error: 'El cuerpo de la petición es demasiado grande.' })
  }
  console.error(err)
  res.status(500).json({ error: 'Error interno del servidor.' })
}

function rutaNoEncontrada(req, res) {
  res.status(404).json({ error: `Ruta no encontrada: ${req.method} ${req.path}` })
}

module.exports = { ErrorHabitos, manejarErrores, rutaNoEncontrada }
