// REPOSITORY: único que lee y escribe datos (archivo JSON)
const fs = require('fs')
const path = require('path')

// Se puede cambiar con la variable HABITOS_DB (los tests usan un archivo temporal)
const archivo = () => process.env.HABITOS_DB || path.join(__dirname, '../../data/habitos.json')

function obtenerTodos() {
  const ruta = archivo()
  if (!fs.existsSync(ruta)) {
    fs.mkdirSync(path.dirname(ruta), { recursive: true })
    fs.writeFileSync(ruta, '[]')
    return []
  }
  let datos
  try {
    datos = JSON.parse(fs.readFileSync(ruta, 'utf-8'))
  } catch (e) {
    throw new Error(`El archivo de datos está dañado o no es JSON válido (${ruta}): ${e.message}`)
  }
  if (!Array.isArray(datos)) throw new Error(`El archivo de datos debe contener una lista (${ruta}).`)
  return datos
}

// Escritura atómica: se escribe a un temporal y se renombra, así un corte no deja el JSON a medias.
// Todo el ciclo leer-modificar-escribir es sincrónico, por lo que dos requests no se pisan.
function escribir(habitos) {
  const ruta = archivo()
  const tmp = `${ruta}.tmp`
  fs.writeFileSync(tmp, JSON.stringify(habitos, null, 2))
  fs.renameSync(tmp, ruta)
}

function obtenerPorId(id) {
  return obtenerTodos().find((h) => h.id === id) || null
}

function guardar(habito) {
  const habitos = obtenerTodos()
  habitos.unshift(habito)
  escribir(habitos)
  return habito
}

// Aplica `cambiar(habito)` al hábito y guarda. Devuelve el hábito nuevo o null si no existe.
function actualizar(id, cambiar) {
  const habitos = obtenerTodos()
  const i = habitos.findIndex((h) => h.id === id)
  if (i === -1) return null
  habitos[i] = cambiar(habitos[i])
  escribir(habitos)
  return habitos[i]
}

function eliminar(id) {
  const habitos = obtenerTodos()
  const restantes = habitos.filter((h) => h.id !== id)
  if (restantes.length === habitos.length) return false
  escribir(restantes)
  return true
}

module.exports = { obtenerTodos, obtenerPorId, guardar, actualizar, eliminar }
