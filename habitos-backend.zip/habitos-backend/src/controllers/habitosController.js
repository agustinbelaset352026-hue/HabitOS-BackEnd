// CONTROLLER: recibe la petición y devuelve la respuesta con el código correcto.
// Cualquier error del Service pasa al middleware de errores (next), así no queda sin capturar.
const service = require('../services/habitosService')

const envolver = (fn) => (req, res, next) => {
  try {
    fn(req, res)
  } catch (err) {
    next(err)
  }
}

module.exports = {
  listar: envolver((req, res) => res.status(200).json(service.listarHabitos(req.query))),
  ver: envolver((req, res) => res.status(200).json(service.verHabito(req.params.id))),
  crear: envolver((req, res) => res.status(201).json(service.crearHabito(req.body))),
  editar: envolver((req, res) => res.status(200).json(service.editarHabito(req.params.id, req.body))),
  eliminar: envolver((req, res) => {
    service.eliminarHabito(req.params.id)
    res.status(200).json({ mensaje: 'Hábito eliminado.' })
  }),
  completar: envolver((req, res) => res.status(200).json(service.completarHoy(req.params.id))),
  favorito: envolver((req, res) => res.status(200).json(service.cambiarFavorito(req.params.id, req.body))),
  estado: envolver((req, res) => res.status(200).json(service.cambiarEstado(req.params.id, req.body))),
  estadisticas: envolver((req, res) => res.status(200).json(service.obtenerEstadisticas(req.params.id))),
}
