// UTILIDADES: validación, normalización y cálculo de rachas (sin tocar archivos ni HTTP)
const ESTADOS = ['activo', 'pausado', 'archivado']
const MAX_TITULO = 100
const MAX_DESCRIPCION = 500

// Fecha local en formato YYYY-MM-DD (no UTC, para que de noche en Argentina no salte al día siguiente)
function hoy(fecha = new Date()) {
  const y = fecha.getFullYear()
  const m = String(fecha.getMonth() + 1).padStart(2, '0')
  const d = String(fecha.getDate()).padStart(2, '0')
  return `${y}-${m}-${d}`
}

// Reglas 1, 2 y 3 del TP. Si el título no es texto devuelve error (400) en vez de romper con 500.
function validarYNormalizarDatosHabito(datos) {
  if (datos === null || typeof datos !== 'object' || Array.isArray(datos)) {
    return { error: 'El cuerpo de la petición debe ser un objeto JSON.', datos: null }
  }
  if (datos.titulo !== undefined && datos.titulo !== null && typeof datos.titulo !== 'string') {
    return { error: 'El título debe ser texto.', datos: null }
  }
  const titulo = (datos.titulo || '').trim()
  if (!titulo) return { error: 'El hábito necesita un título.', datos: null }
  if (titulo.length > MAX_TITULO) {
    return { error: `El título no puede superar los ${MAX_TITULO} caracteres.`, datos: null }
  }

  for (const campo of ['descripcion', 'categoria', 'frecuencia']) {
    if (datos[campo] !== undefined && datos[campo] !== null && typeof datos[campo] !== 'string') {
      return { error: `El campo ${campo} debe ser texto.`, datos: null }
    }
  }
  const descripcion = (datos.descripcion || '').trim()
  if (descripcion.length > MAX_DESCRIPCION) {
    return { error: `La descripción no puede superar los ${MAX_DESCRIPCION} caracteres.`, datos: null }
  }
  if (datos.favorito !== undefined && typeof datos.favorito !== 'boolean') {
    return { error: 'El campo favorito debe ser true o false.', datos: null }
  }
  if (datos.estado !== undefined && !ESTADOS.includes(datos.estado)) {
    return { error: `El estado debe ser: ${ESTADOS.join(', ')}.`, datos: null }
  }

  return {
    error: null,
    datos: {
      titulo,
      descripcion,
      categoria: (datos.categoria || '').trim() || 'Otro',
      frecuencia: datos.frecuencia === 'semanal' ? 'semanal' : 'diaria',
      favorito: datos.favorito, // undefined si no vino
      estado: datos.estado, // undefined si no vino
    },
  }
}

// ---- Rachas y porcentajes (regla 6: se calculan, no se guardan) ----
const diaIndice = (iso) => {
  const [y, m, d] = iso.split('-').map(Number)
  return Math.round(Date.UTC(y, m - 1, d) / 86400000)
}
// Semana que empieza el lunes (el 1/1/1970 fue jueves)
const semanaIndice = (dia) => Math.floor((dia + 3) / 7)

function unidades(historial, frecuencia) {
  const dias = historial.map(diaIndice)
  return new Set(frecuencia === 'semanal' ? dias.map(semanaIndice) : dias)
}

function calcularEstadisticas(habito, fechaHoy = hoy()) {
  const semanal = habito.frecuencia === 'semanal'
  const set = unidades(habito.historial, habito.frecuencia)
  const hoyDia = diaIndice(fechaHoy)
  const unidadHoy = semanal ? semanaIndice(hoyDia) : hoyDia

  // Racha actual: si hoy (o esta semana) todavía no se cumplió, no se corta hasta mañana
  let cursor = set.has(unidadHoy) ? unidadHoy : unidadHoy - 1
  let rachaActual = 0
  while (set.has(cursor)) {
    rachaActual++
    cursor--
  }

  // Racha más larga
  const ordenadas = [...set].sort((a, b) => a - b)
  let rachaMasLarga = 0
  let corrida = 0
  ordenadas.forEach((u, i) => {
    corrida = i > 0 && u === ordenadas[i - 1] + 1 ? corrida + 1 : 1
    rachaMasLarga = Math.max(rachaMasLarga, corrida)
  })

  const porcentaje = (ventana) => {
    const dias = new Set(habito.historial.map(diaIndice))
    const desde = hoyDia - ventana + 1
    const cumplidos = semanal
      ? new Set([...dias].filter((d) => d >= desde && d <= hoyDia).map(semanaIndice)).size
      : [...dias].filter((d) => d >= desde && d <= hoyDia).length
    const objetivo = semanal ? Math.ceil(ventana / 7) : ventana
    return Math.min(100, Math.round((cumplidos / objetivo) * 100))
  }

  return {
    frecuencia: habito.frecuencia,
    unidadRacha: semanal ? 'semanas' : 'días',
    rachaActual,
    rachaMasLarga,
    porcentaje7Dias: porcentaje(7),
    porcentaje30Dias: porcentaje(30),
    totalCompletados: habito.historial.length,
    completadoHoy: habito.historial.includes(fechaHoy),
  }
}

module.exports = { ESTADOS, hoy, validarYNormalizarDatosHabito, calcularEstadisticas }
