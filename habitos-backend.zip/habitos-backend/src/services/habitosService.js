// SERVICE: reglas de negocio
const { randomUUID } = require('crypto')
const repository = require('../repositories/habitosRepository')
const { ErrorHabitos } = require('../middlewares/errores')
const { ESTADOS, hoy, validarYNormalizarDatosHabito, calcularEstadisticas } = require('../utilidades/habitos')

function validar(body) {
  const { error, datos } = validarYNormalizarDatosHabito(body)
  if (error) throw new ErrorHabitos(400, error)
  return datos
}

function obtenerExistente(id) {
  const habito = repository.obtenerPorId(id)
  if (!habito) throw new ErrorHabitos(404, 'El hábito no existe.')
  return habito
}

const sinTildes = (t) => String(t).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase()

function listarHabitos({ buscar, categoria, estado, favorito } = {}) {
  let habitos = repository.obtenerTodos()
  if (estado !== undefined) {
    if (!ESTADOS.includes(estado)) throw new ErrorHabitos(400, `El estado debe ser: ${ESTADOS.join(', ')}.`)
    habitos = habitos.filter((h) => h.estado === estado)
  }
  if (favorito !== undefined) {
    if (!['true', 'false'].includes(favorito)) throw new ErrorHabitos(400, 'favorito debe ser true o false.')
    habitos = habitos.filter((h) => h.favorito === (favorito === 'true'))
  }
  if (typeof categoria === 'string' && categoria.trim()) {
    habitos = habitos.filter((h) => sinTildes(h.categoria) === sinTildes(categoria.trim()))
  }
  if (typeof buscar === 'string' && buscar.trim()) {
    const q = sinTildes(buscar.trim())
    habitos = habitos.filter((h) => sinTildes(h.titulo).includes(q))
  }
  return habitos
}

const verHabito = (id) => obtenerExistente(id)

function crearHabito(body) {
  const datos = validar(body)
  return repository.guardar({
    id: randomUUID(), // antes Date.now(): dos hábitos en el mismo milisegundo repetían id
    titulo: datos.titulo,
    descripcion: datos.descripcion,
    categoria: datos.categoria,
    frecuencia: datos.frecuencia,
    estado: 'activo', // regla 4
    favorito: datos.favorito ?? false,
    historial: [], // regla 4
    creadoEl: hoy(),
  })
}

function editarHabito(id, body) {
  const datos = validar(body)
  obtenerExistente(id)
  return repository.actualizar(id, (h) => ({
    ...h,
    titulo: datos.titulo,
    descripcion: datos.descripcion,
    categoria: datos.categoria,
    frecuencia: datos.frecuencia,
    favorito: datos.favorito ?? h.favorito,
    estado: datos.estado ?? h.estado,
  }))
}

function eliminarHabito(id) {
  if (!repository.eliminar(id)) throw new ErrorHabitos(404, 'El hábito no existe.')
}

function completarHoy(id) {
  const fecha = hoy()
  const habito = obtenerExistente(id)
  if (habito.historial.includes(fecha)) { // regla 5
    throw new ErrorHabitos(409, 'Ese hábito ya está marcado como completado hoy.')
  }
  return repository.actualizar(id, (h) => ({ ...h, historial: [...h.historial, fecha].sort() }))
}

function cambiarFavorito(id, body) {
  const habito = obtenerExistente(id)
  let favorito = !habito.favorito // sin body: alterna
  if (body && body.favorito !== undefined) {
    if (typeof body.favorito !== 'boolean') throw new ErrorHabitos(400, 'El campo favorito debe ser true o false.')
    favorito = body.favorito
  }
  return repository.actualizar(id, (h) => ({ ...h, favorito }))
}

function cambiarEstado(id, body) {
  obtenerExistente(id)
  const estado = body && body.estado
  if (!ESTADOS.includes(estado)) throw new ErrorHabitos(400, `El estado debe ser: ${ESTADOS.join(', ')}.`)
  return repository.actualizar(id, (h) => ({ ...h, estado }))
}

const obtenerEstadisticas = (id) => calcularEstadisticas(obtenerExistente(id))

module.exports = {
  listarHabitos, verHabito, crearHabito, editarHabito, eliminarHabito,
  completarHoy, cambiarFavorito, cambiarEstado, obtenerEstadisticas,
}
