const path = require('path')
const fs = require('fs')
const express = require('express')
const controller = require('./controllers/habitosController')
const { manejarErrores, rutaNoEncontrada } = require('./middlewares/errores')

const app = express()

// CORS simple para que el frontend (React en otro puerto) pueda llamar a la API
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', process.env.CORS_ORIGIN || '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type')
  if (req.method === 'OPTIONS') return res.sendStatus(204)
  next()
})

app.use(express.json({ limit: '100kb' }))

app.get('/habitos', controller.listar)
app.get('/habitos/:id', controller.ver)
app.post('/habitos', controller.crear)
app.put('/habitos/:id', controller.editar)
app.delete('/habitos/:id', controller.eliminar)
app.post('/habitos/:id/completar', controller.completar)
app.patch('/habitos/:id/favorito', controller.favorito)
app.patch('/habitos/:id/estado', controller.estado)
app.get('/habitos/:id/estadisticas', controller.estadisticas)

// Sirve el frontend compilado (frontend/dist) si existe: así todo corre con `npm start`
const dist = path.join(__dirname, '../frontend/dist')
if (fs.existsSync(dist)) app.use(express.static(dist))

app.use(rutaNoEncontrada)
app.use(manejarErrores)

module.exports = app
