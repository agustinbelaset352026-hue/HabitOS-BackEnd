# HábitOS — Backend

API REST para seguir hábitos personales. Node.js + Express, arquitectura **Controller → Service → Repository**, datos en un archivo JSON (un solo usuario, sin login, como define el SPEC).

## Cómo correrlo
```bash
npm start       # http://localhost:3000  → abre la app completa (frontend + API)
npm test        # 11 tests automáticos del backend
```
`node_modules` del backend y el frontend ya compilado (`frontend/dist`) vienen incluidos, no hace falta instalar nada. Si `node_modules` no está, correr `npm install` primero. Requiere Node 18 o más.

### Para modificar el frontend
```bash
cd frontend
npm install
npm run dev     # http://localhost:5173 con recarga en vivo (el backend tiene que estar andando en :3000)
npm run build   # regenera frontend/dist, que es lo que sirve el backend
```
Variables opcionales: `PORT` (3000), `CORS_ORIGIN` (`*`), `HABITOS_DB` (ruta del JSON).

## Estructura
```
src/
  server.js                    arranca el servidor
  app.js                       rutas + CORS + middlewares
  controllers/habitosController.js   request/response y códigos HTTP
  services/habitosService.js         reglas de negocio
  repositories/habitosRepository.js  lectura/escritura del JSON (única capa que toca datos)
  utilidades/habitos.js              validación, normalización, rachas y porcentajes
  middlewares/errores.js             errores siempre en JSON
frontend/                      React + Vite + Tailwind
  src/api.js                   llamadas a la API
  src/useHabitos.js            hook (reemplaza al de localStorage)
  src/components/              FormularioHabito, Filtros, TarjetaHabito
  dist/                        versión compilada que sirve el backend
data/habitos.json              persistencia
test/habitos.test.js
.claude/agents/revisor.md      subagente revisor mejorado
```

## Endpoints
| Método | Ruta | Respuestas |
|---|---|---|
| GET | `/habitos?buscar=&categoria=&estado=&favorito=` | 200 · 400 |
| GET | `/habitos/:id` | 200 · 404 |
| POST | `/habitos` | 201 · 400 |
| PUT | `/habitos/:id` | 200 · 400 · 404 |
| DELETE | `/habitos/:id` | 200 · 404 |
| POST | `/habitos/:id/completar` | 200 · 404 · 409 (ya marcado hoy) |
| PATCH | `/habitos/:id/favorito` | 200 · 400 · 404 (sin body alterna; o `{"favorito":true}`) |
| PATCH | `/habitos/:id/estado` | 200 · 400 · 404 (`{"estado":"pausado"}`) |
| GET | `/habitos/:id/estadisticas` | 200 · 404 |

Ejemplo:
```bash
curl -X POST localhost:3000/habitos -H "Content-Type: application/json" \
  -d '{"titulo":" Tomar agua ","categoria":"Salud","frecuencia":"semanal"}'
```

## Reglas de negocio (TP "Diseñando el backend")
1. Sin título no se guarda (se aplica `trim`). 2. Sin categoría → "Otro". 3. Frecuencia distinta de "semanal" → "diaria". 4. Hábito nuevo: estado "activo" e historial vacío. 5. No se marca dos veces el mismo día (409). 6. Rachas y porcentajes se calculan desde el historial (hábitos semanales cuentan semanas, lunes a domingo).

## Qué se incorporó de cada TP
- **Diseñando el backend**: las tres capas, los 9 endpoints y los códigos 201/200/400/404/409. Se mantuvo la decisión de no usar login ni base pesada.
- **Medí tu revisor** (hallazgos del revisor, ya corregidos):
  - `Date.now()` repetía ids → ahora `crypto.randomUUID()`.
  - Un título que no es texto daba 500 → ahora 400.
  - JSON mal formado devolvía HTML → ahora middleware de errores con respuesta JSON.
  - Archivo de datos dañado → error claro y controlado; escritura atómica (temporal + rename).
  - El controller no capturaba errores del service → todo pasa por `next(err)`.
- **Mejorá el agente**: `.claude/agents/revisor.md` con los 5 cambios y la pregunta 3 ampliada ("o cuando dos cosas pasan al mismo tiempo"); además le agregué que lo que resuelve otro archivo se marca "No verificado" y no como problema (el fallo del archivo sano).
- **Analizar antes de pedir**: ese TP trata de otra app (tickets con SQL Server), así que no se incluye código de eso. Se aplicó la idea: no armar consultas con texto del usuario (acá no hay SQL) y no abrir recursos nuevos en cada request.

## Frontend
React + Tailwind, responsive. Permite crear, editar y eliminar hábitos, marcar completado hoy, favorito, cambiar estado, buscar y filtrar por categoría/estado/favorito, y ver racha actual, mejor racha y porcentaje de 7 y 30 días. Valida el título en pantalla para avisar rápido, pero la validación de verdad es la del backend. Los errores del servidor se muestran en un aviso rojo.

## Para migrar a una base de datos más adelante
Solo hay que reescribir `habitosRepository.js` manteniendo sus funciones; el resto no cambia.
