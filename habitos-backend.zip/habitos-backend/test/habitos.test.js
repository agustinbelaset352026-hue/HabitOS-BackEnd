const { test, before, after, beforeEach } = require('node:test')
const assert = require('node:assert')
const fs = require('fs')
const os = require('os')
const path = require('path')

const tmp = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'habitos-')), 'habitos.json')
process.env.HABITOS_DB = tmp
const app = require('../src/app')
const { calcularEstadisticas, hoy } = require('../src/utilidades/habitos')

let server, base
before(() => new Promise((r) => { server = app.listen(0, () => { base = `http://localhost:${server.address().port}`; r() }) }))
after(() => server.close())
beforeEach(() => fs.writeFileSync(tmp, '[]'))

const pedir = async (metodo, ruta, body, raw) => {
  const res = await fetch(base + ruta, {
    method: metodo,
    headers: { 'Content-Type': 'application/json' },
    body: raw ?? (body === undefined ? undefined : JSON.stringify(body)),
  })
  return { status: res.status, json: await res.json() }
}

test('Prueba 1 del TP: hábito válido con espacios en el título', async () => {
  const { status, json } = await pedir('POST', '/habitos', { titulo: ' Tomar agua ', descripcion: '2 litros', categoria: 'Salud', frecuencia: 'semanal' })
  assert.equal(status, 201)
  assert.equal(json.titulo, 'Tomar agua')
  assert.equal(json.estado, 'activo')
  assert.deepEqual(json.historial, [])
})

test('Prueba 2 del TP: título vacío -> 400', async () => {
  const { status, json } = await pedir('POST', '/habitos', { titulo: ' ' })
  assert.equal(status, 400)
  assert.equal(json.error, 'El hábito necesita un título.')
})

test('Prueba 3 del TP: valores por defecto', async () => {
  const { json } = await pedir('POST', '/habitos', { titulo: 'Leer' })
  assert.equal(json.categoria, 'Otro')
  assert.equal(json.frecuencia, 'diaria')
})

test('título que no es texto -> 400 (antes era 500)', async () => {
  const { status } = await pedir('POST', '/habitos', { titulo: 123 })
  assert.equal(status, 400)
})

test('JSON mal formado -> 400 en JSON (no HTML)', async () => {
  const { status, json } = await pedir('POST', '/habitos', undefined, '{"titulo": ')
  assert.equal(status, 400)
  assert.ok(json.error)
})

test('ids únicos aunque se creen a la vez', async () => {
  const rs = await Promise.all(Array.from({ length: 20 }, (_, i) => pedir('POST', '/habitos', { titulo: `H${i}` })))
  assert.equal(new Set(rs.map((r) => r.json.id)).size, 20)
  assert.equal((await pedir('GET', '/habitos')).json.length, 20)
})

test('archivo dañado -> 500 controlado en JSON', async () => {
  fs.writeFileSync(tmp, '{roto')
  const origen = console.error; console.error = () => {}
  const { status, json } = await pedir('GET', '/habitos')
  console.error = origen
  assert.equal(status, 500)
  assert.equal(json.error, 'Error interno del servidor.')
})

test('CRUD, 404, favorito, estado y filtros', async () => {
  const a = (await pedir('POST', '/habitos', { titulo: 'Meditar', categoria: 'Mente' })).json
  await pedir('POST', '/habitos', { titulo: 'Correr', categoria: 'Salud' })
  assert.equal((await pedir('GET', `/habitos/${a.id}`)).status, 200)
  assert.equal((await pedir('GET', '/habitos/nada')).status, 404)
  assert.equal((await pedir('PUT', `/habitos/${a.id}`, { titulo: 'Meditar 10 min' })).json.titulo, 'Meditar 10 min')
  assert.equal((await pedir('PATCH', `/habitos/${a.id}/favorito`)).json.favorito, true)
  assert.equal((await pedir('PATCH', `/habitos/${a.id}/estado`, { estado: 'pausado' })).json.estado, 'pausado')
  assert.equal((await pedir('PATCH', `/habitos/${a.id}/estado`, { estado: 'x' })).status, 400)
  assert.equal((await pedir('GET', '/habitos?buscar=MEDITAR')).json.length, 1)
  assert.equal((await pedir('GET', '/habitos?categoria=salud')).json.length, 1)
  assert.equal((await pedir('GET', '/habitos?favorito=true')).json.length, 1)
  assert.equal((await pedir('GET', '/habitos?estado=pausado')).json.length, 1)
  assert.equal((await pedir('DELETE', `/habitos/${a.id}`)).status, 200)
  assert.equal((await pedir('DELETE', `/habitos/${a.id}`)).status, 404)
})

test('completar: 200 la primera vez, 409 la segunda', async () => {
  const a = (await pedir('POST', '/habitos', { titulo: 'Leer' })).json
  const r1 = await pedir('POST', `/habitos/${a.id}/completar`)
  assert.equal(r1.status, 200)
  assert.deepEqual(r1.json.historial, [hoy()])
  assert.equal((await pedir('POST', `/habitos/${a.id}/completar`)).status, 409)
  const est = (await pedir('GET', `/habitos/${a.id}/estadisticas`)).json
  assert.equal(est.rachaActual, 1)
  assert.equal(est.completadoHoy, true)
})

test('estadísticas: rachas y porcentajes (diaria)', () => {
  const h = { frecuencia: 'diaria', historial: ['2026-11-01', '2026-11-02', '2026-11-03', '2026-11-08', '2026-11-09', '2026-11-10'] }
  const e = calcularEstadisticas(h, '2026-11-10')
  assert.equal(e.rachaActual, 3)
  assert.equal(e.rachaMasLarga, 3)
  assert.equal(e.porcentaje7Dias, Math.round((3 / 7) * 100))
  assert.equal(e.porcentaje30Dias, 20)
  // si hoy no se cumplió pero ayer sí, la racha sigue viva
  assert.equal(calcularEstadisticas(h, '2026-11-11').rachaActual, 3)
  assert.equal(calcularEstadisticas(h, '2026-11-12').rachaActual, 0)
})

test('estadísticas: hábito semanal cuenta semanas', () => {
  const h = { frecuencia: 'semanal', historial: ['2026-10-27', '2026-11-05', '2026-11-10'] } // semanas lun 26/10, 2/11, 9/11
  const e = calcularEstadisticas(h, '2026-11-10')
  assert.equal(e.rachaActual, 3)
  assert.equal(e.unidadRacha, 'semanas')
})
